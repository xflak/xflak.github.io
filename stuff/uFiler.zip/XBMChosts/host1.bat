::Update only what comes after the equal signs
set username=xbmc
set password=pass
set hostname=localhost
set port=8080
set DownloadStartPopup=Y
::All timers are measured in milliseconds
set DownloadStartPopupTimer=10000
set DownloadStartImage=
::xbmcLocalLaunch only applicable when hostname=localhost
::If the host is the same PC running uFiler (i.e. localhost) recommend enabling xbmcLocalLaunch and updatelibrary and configure xbmc to NOT update it's library at startup
set xbmcLocalLaunch=Y
set updatelibrary=Y
set ShowAddedPopup=Y
set ShowAddedPopupTimer=10000
set ShowAddedImage=
set CopyMovePopup=Y
set CopyMovePopupTimer=10000
set CopyMoveImage=
::replace image spaces with %%20 (if applicable), examples: special://profile/tv.png, smb://192.168.1.99/Shared%%20Folder/tv.png, http://fc06.deviantart.net/fs70/f/2013/147/6/f/tv_show_folder_icon_by_leftright-d66qz0k.png