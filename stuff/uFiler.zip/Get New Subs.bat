@echo off
setlocal

set filebot="uninstalled"
if exist "%homedrive%\Program Files (x86)\FileBot\filebot.exe" set filebot="%homedrive%\Program Files (x86)\FileBot\filebot.exe"
if exist "%homedrive%\Program Files\FileBot\filebot.exe" set filebot="%homedrive%\Program Files\FileBot\filebot.exe"
if /i %filebot% EQU "uninstalled" exit

if not exist settings.bat (exit) else (call settings.bat)

%filebot% -script fn:suball "%TVFolder%" "%MovieFolder%" --lang %SubtitleLang% --output srt --encoding utf8 -non-strict --def maxAgeDays=14 --format MATCH_VIDEO --log INFO
