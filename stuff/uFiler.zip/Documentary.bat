echo running "Documentary.bat"
echo.

::treat Documentaries like 'TV' but with alternative 'TVFolder' destination
set label=TV

::Don't override original label for directory purposes since files aren't being moved
::set LabelOriginal=TV

::if state is NOT "Finished" then go back
::if /i "%state%" NEQ "11" goto:back

::customize with alternate directory
set TVFolder=\\192.168.2.99\video\Documentaries

echo returning to ufiler.bat
echo.
