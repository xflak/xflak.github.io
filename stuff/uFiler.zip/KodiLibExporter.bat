@echo off
setlocal
set PATH=%SystemRoot%\system32;%SystemRoot%\system32\wbem;%SystemRoot%
chcp 437>nul
set workingdir=%cd%

echo Kodi\XBMC Library Exporter
echo.

::If launching via task scheduler be sure to add "Start in" directory to task scheduler "action"

::Update the following lines with your unique preferences
set hostname=localhost
set port=8080
set username=xbmc
set password=remember
set overwrite=false
set images=true
set actorthumbs=false
::xbmcLocalLaunch only applicable when hostname=localhost
set xbmcLocalLaunch=Y


::Launch XBMC if installed (unless disabled or it's already running)
if /i "%hostname%" NEQ "localhost" goto:skiplaunch
if /i "%xbmcLocalLaunch%" NEQ "Y" goto:skiplaunch

::get kodi install path
echo Discovering where\if Kodi is installed...
echo.

reg query HKEY_CURRENT_USER\Software\kodi|findstr /I /C:"Default">"%temp%\temp.txt"
set /p kodipath= <"%temp%\temp.txt"
if "%kodipath%"=="" goto:skipkodi
set kodipath=%kodipath:*REG_SZ    =%

echo Checking if kodi is running...
echo.

::Only launch kodi if not already running
tasklist /nh /fi "imagename eq kodi.exe" | find /i "kodi.exe" >nul && (
echo kodi is already running
echo.
goto:skiplaunch
) || (
echo kodi not running
echo.
)

echo Starting kodi...
echo.
Start /D "%kodipath%" kodi.exe
echo Giving kodi some time to start up...
echo.
@ping 127.0.0.1 -n 60 -w 1000> nul
goto:skiplaunch

:skipkodi



::get xbmc install path
echo Discovering where\if xbmc is installed...
echo.

reg query HKEY_CURRENT_USER\Software\xbmc|findstr /I /C:"Default">"%temp%\temp.txt"
set /p xbmcpath= <"%temp%\temp.txt"
if "%xbmcpath%"=="" goto:skiplaunch
set xbmcpath=%xbmcpath:*REG_SZ    =%

echo Checking if xbmc is running...
echo.

::Only launch xbmc if not already running
tasklist /nh /fi "imagename eq xbmc.exe" | find /i "xbmc.exe" >nul && (
echo xbmc is already running
echo.
goto:skiplaunch
) || (
echo xbmc not running
echo.
)

echo Starting xbmc...
echo.
Start /D "%xbmcpath%" xbmc.exe
echo Giving xbmc some time to start up...
echo.
@ping 127.0.0.1 -n 60 -w 1000> nul

:skiplaunch



"%workingdir%\curl.exe" -X POST -H "content-type: application/json;" --data "{ \"jsonrpc\": \"2.0\", \"method\": \"VideoLibrary.Export\", \"params\": { \"options\": { \"overwrite\": %overwrite%, \"actorthumbs\": %actorthumbs%, \"images\": %images%} }, \"id\": \"mybash\"}" http://%username%:%password%@%hostname%:%port%/jsonrpc

::> NUL 2>&1


::Clean temp folder
if exist "%temp%\temp.txt" del /f /q "%temp%\temp.txt">nul
if exist "%temp%\jsonrpc@request*" del /f /q "%temp%\jsonrpc@request*">nul

::echo fin
::pause

exit

