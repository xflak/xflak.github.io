::Update only what comes after the equal signs
::Escape any special characters [i.e. ()|] by inserting a carrot ^ in front, so for example (Movies) becomes ^(Movies^)
::Do not use quotations marks ""

::set uCompletedDownloads to the folder uTorrent is set to move completed downloads to
set uCompletedDownloads=C:\Users\XFlak\Downloads

::set TVFolder and MovieFolder to the locations of your TV and Movie library, respectively
set TVFolder=\\NAS\TV Shows
set MovieFolder=\\NAS\Movies

::set copyORmove to either "copy" or "move" depending on whether you want videos copied or moved. Note that move operations are only triggered when a torrent is "Finished" whereas copy operations are triggered when torrents are seeding and\or finished.
set copyORmove=copy

::set GetSubtitles to "Y" or "N"
set GetSubtitles=Y

::two letter language codes found here: http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
set SubtitleLang=en

::If uFiler is installed on the same machine running Plex Media Server, it can update the Plex Library for just the affected folders (i.e. fast\partial scan). Set updatePlexLibrary to "localhost" or "Y" to do a fast\partial scan, if Plex isn't installed it won't run. To update a remote plex library running on a different machine, set updatePlexLibrary to the LAN IP address of that host (e.g. 192.168.2.40). If updating a remote plex library, you'll also need to update the PlexToken below (instructions on finding your plex token are here: http://tiny.cc/plextoken). To disable all plex updates set updatePlexLibrary to N
set updatePlexLibrary=localhost
set PlexToken=0123456789abcdefghij
set PlexPort=32400

::Optionally customize TVFormat and MovieFormat expressions to change how videos are named. For most people the default values will be satisfactory. Do not change these settings unless you know what you're doing. Information on how to customize these can be found at www.filebot.net/naming.html (do not forget to escape special characters)

set TVFormat={n}\{episode.special ? 'Season 0' : 'Season '+s}\{s00e00} {t}{' ['+vf.match^(/720[pP]^|1080[pP]/^)+']'}{lang =~ 'eng' ? null : '.'+ lang}

::Optionally override TV Series names by creating\editing a "list.csv" file in the same folder as uFiler. Each line should contain the original name then the new name separated by a semi-colon, for example "Star Trek The Next Generation;STNG" (without quotes), for example

::set TVFormat={csv^('C:/Users/Admin/Documents/uFiler/list.csv'^).get^(n^) ?: n}\{episode.special ? 'Season 0' : 'Season '+s}\{s00e00} {t}{' ['+vf.match^(/720[pP]^|1080[pP]/^)+']'}{lang =~ 'eng' ? null : '.'+ lang}

set MovieFormat={n} {'^('+y+'^)'}{' ['+vf.match^(/720[pP]^|1080[pP]/^)+']'}/{n} {'^('+y+'^)'}{' ['+vf.match^(/720[pP]^|1080[pP]/^)+']'}{lang =~ 'eng' ? null : '.'+ lang}
