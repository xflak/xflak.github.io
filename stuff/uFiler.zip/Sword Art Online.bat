echo running "Sword Art Online.bat"
echo.

::if state is NOT "Finished" then override label to TV and go back
if /i "%state%" NEQ "11" set label=TV
if /i "%state%" NEQ "11" goto:back

::echo workingdir is %workingdir%
::echo label is %label%
::echo state is %state%
::echo previousstate is %previousstate%
::echo torrentname is %torrentname%
::echo downloadpath is %downloadpath%
::echo kind is %kind%
::kind of torrent (single|multi)

::this code only written for single!
if /i "%kind%" NEQ "single" goto:back

set file=%torrentname%

::Example
::[HorribleSubs] Sword Art Online - Alicization - 08 [720p].mkv
::echo %file%
set file2=%file:Alicization - =S03E%

move /Y "%downloadpath%\%file%" "%uCompletedDownloads%\TV\%file2%"> nul

:next
cd /d "%workingdir%"

::override label to TV and chance download path
set label=TV
set LabelOriginal=TV
set downloadpath=%uCompletedDownloads%\TV

echo returning to ufiler.bat
echo.

:back