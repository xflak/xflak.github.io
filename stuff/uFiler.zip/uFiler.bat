@echo off
setlocal
set PATH=%SystemRoot%\system32;%SystemRoot%\system32\wbem;%SystemRoot%
chcp 437>nul
::utorrent
::"<Path2exe>\uFiler.exe" "<Path2exe>" "%L" "%S" "%P" "%N" "%D" "%K"
::qbit added
::"<Path2exe>\uFiler.exe" "<Path2exe>" "%L" "12" "12" "%N" "%D" "%C"
::qbit completed
::"<Path2exe>\uFiler.exe" "<Path2exe>" "%L" "11" "11" "%N" "%D" "%C"
::qbit, in RSS Downloader for EACH tv show change save at path to your `uCompletedDownloads` folder and add "\TV" (e.g. D:\Downloads\uTorrent\TV), also make sure category is set to TV

set workingdir=%~1
set label=%~2
set state=%~3
set previousstate=%~4
set torrentname=%~5
set downloadpath=%~6
set kind=%~7
::kind of torrent (single|multi)
if /i "%kind%" EQU "1" (set kind=single) else (set kind=multi)

set version=3.6

echo uFiler v%version%
echo -----------
echo.

if "%workingdir%"=="" goto:noargs

::when launched via utorrent, path retrievals fail, must be set as argument
if not exist "%workingdir%" exit
cd /d "%workingdir%"


::default settings
set TVFormat={n}\{episode.special ? 'Season 0' : 'Season '+s}\{s00e00} {t}{' ['+vf.match^(/720[pP]^|1080[pP]/^)+']'}{lang =~ 'eng' ? null : '.'+ lang}
set MovieFormat={n} {'^('+y+'^)'}{' ['+vf.match^(/720[pP]^|1080[pP]/^)+']'}/{n} {'^('+y+'^)'}{' ['+vf.match^(/720[pP]^|1080[pP]/^)+']'}{' ^(Part'+pi+'^)'}{lang =~ 'eng' ? null : '.'+ lang}
set copyORmove=move
set GetSubtitles=Y
set SubtitleLang=en
set updatePlexLibrary=Y


if exist settings.bat call settings.bat

::for custom overrides or tweaks, first grab original label for directory purposes
set LabelOriginal=%label%
if exist "%LabelOriginal%.bat" call "%LabelOriginal%.bat"

if /i "%label:~0,3%" EQU "-c " (set mode=COPY) & (goto:simplemovecopy)
if /i "%label:~0,3%" EQU "-m " (set mode=MOVE) & (goto:simplemovecopy)
if /i "%label:~0,4%" EQU "-cp " (set mode=COPY) & (goto:simplemovecopy)
if /i "%label:~0,4%" EQU "-mp " (set mode=MOVE) & (goto:simplemovecopy)

if /i "%label%" EQU "teamviewer" goto:teamviewerlaunch
if /i "%label:~0,5%" EQU "kill " goto:taskkill
if /i "%label%" EQU "TV" goto:TV
if /i "%label%" EQU "Movie" goto:Movie
set force=
if /i "%label%" EQU "F" (set state=F) & (set force=Y) & (set label=TV) & (set LabelOriginal=TV) & (goto:TV)

goto:noargs


:TV

::Queued utorrent state (12)
if /i "%state%" NEQ "F" if /i "%previousstate%" EQU "12" goto:DOWNLOADSTART

if not exist settings.bat goto:cleantemp

if "%uCompletedDownloads%"=="" goto:cleantemp
if "%TVFolder%"=="" goto:cleantemp

if not exist "%uCompletedDownloads%" goto:cleantemp

if not exist "%TVFolder%" mkdir "%TVFolder%"

if not exist "%TVFolder%" goto:cleantemp


::if copyORmove=move, trigger completion at torrent finished state (11), otherwise trigger completion at seeding (or finished) state (4,5,7,8,10)
::even if triggered multiple times, duplicate notifications will not appear because filebot will only log it once

::FORCE run
if /i "%state%" EQU "F" goto:FINISHED

::For Move operations

if /i "%copyORmove%" NEQ "move" goto:skip
if /i "%state%" EQU "11" goto:FINISHED
goto:cleantemp

::For Copy disabled
:skip
if /i "%state%" EQU "4" goto:FINISHED
if /i "%state%" EQU "5" goto:FINISHED
if /i "%state%" EQU "7" goto:FINISHED
if /i "%state%" EQU "8" goto:FINISHED
if /i "%state%" EQU "10" goto:FINISHED
if /i "%state%" EQU "11" goto:FINISHED
goto:cleantemp



:DOWNLOADSTART
set torrentname=%torrentname: =.%

::LOOP through all the xbmc hosts

::dir /s for full path (recursive)
dir /b /s "%workingdir%\XBMChosts">"%temp%\temp.txt"
findstr /I /E /C:".bat" "%temp%\temp.txt" >"%temp%\temp2.txt"
findstr /I /C:"\host" "%temp%\temp2.txt" >"%temp%\xbmchosts.txt"


set hostnum=0
::set maxtimer=0
::Loop through the the following once for EACH line in *.txt
cd /d "%temp%"
for /F "tokens=*" %%A in (xbmchosts.txt) do call :hostActionStart %%A
goto:hostActionStartComplete

:hostActionStart
set /a hostnum=%hostnum%+1
set hostfile=%*
::clear values, just in case
set username=xbmc
set password=pass
set hostname=localhost
set port=8080
set DownloadStartPopup=Y
set DownloadStartPopupTimer=10000
set DownloadStartImage=

call "%hostfile%"

if /i %DownloadStartPopupTimer% LSS 1500 set DownloadStartPopupTimer=1500

if /i "%DownloadStartPopup%" NEQ "Y" goto:EOF

echo Notifying %hostnum%: %hostname%:%port%...
echo.
::cd /d "%temp%"
::ping -n 1 "%hostname%"|findstr /I /C:"ms"
::IF NOT ERRORLEVEL 1 

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"GUI.ShowNotification\", \"params\":{\"title\": \"New Download Started...\",\"message\": \"%torrentname%\",\"displaytime\": %DownloadStartPopupTimer%,\"image\": \"%DownloadStartImage%\"}, \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1


::"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --user="%username%" --password="%password%" --quiet "%hostname%:%port%/jsonrpc?request={%%22jsonrpc%%22:%%222.0%%22,%%22method%%22:%%22GUI.ShowNotification%%22,%%22params%%22:{%%22title%%22:%%22New%%20Download%%20Started...%%22,%%22message%%22:%%22%torrentname%%%22,%%22displaytime%%22:%DownloadStartPopupTimer%,%%22image%%22:%%22%DownloadStartImage%%%22},%%22id%%22:1}"


::cd /d "%workingdir%"

::LOG!
if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo DOWNLOAD START NOTIFICATION: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %torrentname% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"
goto:EOF

:hostActionStartComplete
cd /d "%workingdir%"
goto:cleantemp



:FINISHED
echo TV Finished Process
echo.
set filebot="uninstalled"
if exist "%homedrive%\Program Files (x86)\FileBot\filebot.exe" set filebot="%homedrive%\Program Files (x86)\FileBot\filebot.exe"
if exist "%homedrive%\Program Files\FileBot\filebot.exe" set filebot="%homedrive%\Program Files\FileBot\filebot.exe"
if /i %filebot% EQU "uninstalled" goto:cleantemp

set updateskipped=

::TO DO - override uCompletedDownloads with uTorrent label
::if not exist "%uCompletedDownloads%" goto:cleantemp

::clean "%uCompletedDownloads%\%LabelOriginal%" (only if copyORmove=move to not disrupt seeding)
if /i "%copyORmove%" NEQ "move" goto:skip

echo Cleaning fetchfolder of:
echo txt, nfo, jpg, png, ac3, ~uTorrentPart dat files, empty folders and
echo sample files based on name or size --less than 30MB and not a subtitle extension--
echo.

del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.jpg">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.png">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.txt">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.nfo">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.ac3">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*~uTorrentPartFile*.dat">nul
::delete samples
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*sample*">nul
::delete video files that are less than 30MB (or 31457280 in bytes)
for /f "delims=" %%d in ('dir /s /b /a-d "%uCompletedDownloads%\%LabelOriginal%\*" ^| findstr /I /V ".srt .sub .ssa .sbv"') do if %%~zd lss 31457280 del /s /f /q "%%~d"

for /f "delims=" %%d in ('dir /s /b /ad "%uCompletedDownloads%\%LabelOriginal%\" ^| sort /r') do rd "%%d"
echo.
:skip


if /i "%GetSubtitles%" NEQ "Y" goto:skip
echo Checking for subtitles...
echo.
%filebot% -script fn:suball "%uCompletedDownloads%\%LabelOriginal%" --lang %SubtitleLang% --output srt --encoding utf8 -non-strict --format MATCH_VIDEO
echo.
:skip


echo Launching filebot to %copyORmove% and rename files...
echo.

::change conflict handling from auto to override for 'repack' and 'proper' downloads
set conflict=auto
echo "%torrentname%"|findstr /I /C:"repack" /C:"proper" >nul
if "%errorlevel%" EQU "0" set conflict=override
::echo %conflict%

::if not exist list.csv echo Star Trek The Next Generation;STNG>>list.csv

::Jersey Shore Family Vacation override, may interfere with Jersey Shore and Geordie Shore, requires 
%filebot% -rename --filter "n != /Jersey Shore/ && n != /Geordie Shore/" --action %copyORmove% --conflict %conflict% --db theTVDB -r -non-strict --format "%TVFolder%\%TVFormat%" "%uCompletedDownloads%\%LabelOriginal%">"%temp%\log.txt" 2>&1

::replaced "--db theTVDB" with "--db TheMovieDB::TV"

::original 
::%filebot% -rename --action %copyORmove% --conflict %conflict% --db theTVDB -r -non-strict --format "%TVFolder%\%TVFormat%" "%uCompletedDownloads%\%LabelOriginal%">"%temp%\log.txt" 2>&1


if /i "%copyORmove%" EQU "move" echo Launching filebot to clean files...
if /i "%copyORmove%" EQU "move" echo.
if /i "%copyORmove%" EQU "move" %filebot% -script fn:cleaner "%uCompletedDownloads%\%LabelOriginal%"

echo Reading logs...
echo.

cd /d "%temp%"

::remove sub lines

::findstr /I /V ".srt .sub .idx .jpg .nfo" "%temp%\log.txt" >"%temp%\temp.txt"
::above doesn't consider periods, i.e. excludes "HorribleSubs" because of ".sub"

findstr /I /V /C:".srt" "%temp%\log.txt" >"%temp%\temp.txt"
findstr /I /V /C:".sub" "%temp%\temp.txt" >"%temp%\log.txt"
findstr /I /V /C:".idx" "%temp%\log.txt" >"%temp%\temp.txt"
findstr /I /V /C:".jpg" "%temp%\temp.txt" >"%temp%\log.txt"
findstr /I /V /C:".nfo" "%temp%\log.txt" >"%temp%\temp.txt"

::Count NEW
findstr /I /C:"] to [" "%temp%\temp.txt" >"%temp%\log.txt"

set TotalNotificationS=0
::Loop through the the following once for EACH line in *.txt
for /F "tokens=*" %%A in (log.txt) do call :countnum "%%A"
goto:quickskip
:countnum
set /a TotalNotificationS=%TotalNotificationS%+1
goto:EOF
:quickskip
echo TotalNotifications %TotalNotificationS%
echo.

cd /d "%workingdir%"

:skipcount


set /a notification=0


:RepeatNotification
if /i %notification% EQU %TotalNotificationS% goto:donenotifications
set /a notification=%notification%+1

echo.
echo Notification %notification%

::Number the list
findstr /I /N "." "%temp%\log.txt" >"%temp%\temp.txt"

::pull episode name and series name from notification #
findstr /I /B /C:"%notification%:" "%temp%\temp.txt" >"%temp%\temp2.txt"
set /p showname= <"%temp%\temp2.txt"

echo set showname=%%showname:*%TVFolder%\=%%>"%temp%\temp.bat"
call "%temp%\temp.bat"
set showname=%showname:~0,-1%
::echo showname %showname%

set episodename=%showname:*\=%
echo set seriesname=%%showname:\%episodename%=%%>"%temp%\temp.bat"
call "%temp%\temp.bat"

if "%seriesname:~-4,1%" EQU "." set seriesname=%seriesname:~0,-4%
if "%seriesname:~-5,1%" EQU "." set seriesname=%seriesname:~0,-5%

::echo seriesname %seriesname%

set episodename=%episodename:*\=%
set episodename=%episodename:*\=%
set episodename=%episodename:*\=%

::Get videofolder
echo set videofolder=%%showname:%episodename%=%%>"%temp%\temp.bat"
call "%temp%\temp.bat"

if not "%videofolder%"=="" set videofolder=%TVFolder%\%videofolder%
if "%videofolder%"=="" set videofolder=%TVFolder%
if "%videofolder:~-1,1%" EQU "\" set videofolder=%videofolder:~0,-1%

::echo videofolder %videofolder%

if "%episodename:~-1,1%" EQU "\" set episodename=%episodename:~0,-1%
set episodename=%episodename:~0,-4%
if "%episodename:~-1,1%" EQU "." set episodename=%episodename:~0,-1%
::echo episodename %episodename%

echo.
echo %notification%: %seriesname%: %episodename%


::UpdatePlexLibrary

if "%updatePlexLibrary%" EQU "N" goto:skipPlexUpdate
if "%updatePlexLibrary%" EQU "localhost" goto:localhostplexupdate
if "%updatePlexLibrary%" EQU "Y" goto:localhostplexupdate

::remote plex library update

::get Section #
"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --quiet "http://%updatePlexLibrary%:%PlexPort%/library/sections?X-Plex-Token=%PlexToken%" -O "%temp%\temp.txt"

::redirects fail for findstr commands containing escaped characters, work around by calling other bat file
echo @findstr /I /C:^"title=\^"%%1^" ^"%%temp%%\temp.txt^">"%temp%\myfindstr.bat"
call "%temp%\myfindstr.bat" %label% >"%temp%\temp2.txt"

set /p section= <"%temp%\temp2.txt"

set section=%section:*sections/=%
if "%section:~1,1%" EQU "/" (set section=%section:~0,1%) & (goto:gotsection)
if "%section:~2,1%" EQU "/" (set section=%section:~0,2%) & (goto:gotsection)
if "%section:~3,1%" EQU "/" (set section=%section:~0,3%) & (goto:gotsection)
if "%section:~4,1%" EQU "/" (set section=%section:~0,4%) & (goto:gotsection)
if "%section:~5,1%" EQU "/" (set section=%section:~0,5%) & (goto:gotsection)
:gotsection
::echo %section%

::send update command
echo Updating %label% Plex Library: %updatePlexLibrary%:%PlexPort%
echo.

"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --quiet "http://%updatePlexLibrary%:%PlexPort%/library/sections/%section%/refresh?X-Plex-Token=%PlexToken%" -O "%temp%\temp.txt"


goto:skipPlexUpdate


::Local UpdatePlexLibrary, only for the specific "%videofolder%"

:localhostplexupdate
if "%updatePlexLibrary%" NEQ "localhost" goto:skipPlexUpdate

set PMS="uninstalled"
if exist "%homedrive%\Program Files (x86)\Plex\Plex Media Server\Plex Media Scanner.exe" set PMS="%homedrive%\Program Files (x86)\Plex\Plex Media Server\Plex Media Scanner.exe"
if exist "%homedrive%\Program Files\Plex\Plex Media Server\Plex Media Scanner.exe" set PMS="%homedrive%\Program Files\Plex\Plex Media Server\Plex Media Scanner.exe"
if /i %PMS% EQU "uninstalled" goto:skipPlexUpdate

::get TV section number
%PMS% --list|findstr /I /C:" %label%">"%temp%\temp.txt"

set /p section= <"%temp%\temp.txt"
if "%section%"=="" goto:skipPlexUpdate

set section=%section: =%
if /i "%section:~1,1%" EQU ":" set section=%section:~0,1%
if /i "%section:~2,1%" EQU ":" set section=%section:~0,2%
if /i "%section:~3,1%" EQU ":" set section=%section:~0,3%
if "%section%"=="" goto:skipPlexUpdate

::When PMS adds the first episode of a season it needs to scan the entire series folder, the season subdirectory isn't enough. To work around this, when adding the first episode of a season, or any videos from Season 1, uFiler will have PMS scan the entire series folder. This should work in all situations except when the first episode of a season being added to your library is not the first episode or from Season 1. In those cases the scheduled PMS library updates will do the initial scan of the season, and uFiler's updates will be done successfully in realtime from then going forward. This is all to avoid scanning the entire series folder each time a video is added as it requires more time to do, especially for series with lots of episodes.

if /i "%videofolder%" EQU "%TVFolder%" goto:skip
echo "%videofolder%"|findstr /I /C:"\Season 1" /C:"\Season 01" >nul
if "%errorlevel%" EQU "0" set videofolder=%TVFolder%\%seriesname%
echo "%episodename%"|findstr /I /C:"S01" /C:"1x" /C:"01x" /C:"E01" /C:"x01" /C:"x1" >nul
if "%errorlevel%" EQU "0" set videofolder=%TVFolder%\%seriesname%
:skip


echo Updating Plex Library
echo --scan --refresh --section %section% -d "%videofolder%"
echo.
%PMS% --scan --refresh --section %section% -d "%videofolder%"
echo.
:skipPlexUpdate


::replace ampersands ("&") with "and"
set seriesname=%seriesname:&=^&%
set episodename=%episodename:&=^&%
set seriesname=%seriesname:^&=and%
set episodename=%episodename:^&=and%

::replace spaces with %%20 (not longer needed after switching to curl)
set adjseriesname=%seriesname%
set adjepisodename=%episodename%
::setlocal ENABLEDELAYEDEXPANSION
::set adjseriesname=!seriesname: =%%20!
::set adjepisodename=!episodename: =%%20!
::setlocal DISABLEDELAYEDEXPANSION

::echo %adjseriesname%
::echo %adjepisodename%


::LOOP through all the xbmc hosts
::dir /s for full path (recursive)
dir /b /s "%workingdir%\XBMChosts">"%temp%\temp.txt"
findstr /I /E /C:".bat" "%temp%\temp.txt" >"%temp%\temp2.txt"
findstr /I /C:"\host" "%temp%\temp2.txt" >"%temp%\xbmchosts.txt"


set hostnum=0
set maxtimer=0
::Loop through the the following once for EACH line in *.txt
cd /d "%temp%"
for /F "tokens=*" %%A in (xbmchosts.txt) do call :hostActionFinished %%A
goto:hostActionFinishedComplete

:hostActionFinished
set /a hostnum=%hostnum%+1
set hostfile=%*

::clear values, just in case
set username=xbmc
set password=pass
set hostname=localhost
set port=8080
set updatelibrary=Y
set ShowAddedPopup=Y
set ShowAddedPopupTimer=5000
set ShowAddedImage=
set xbmcLocalLaunch=Y

call "%hostfile%"

if /i %ShowAddedPopupTimer% LSS 1500 set ShowAddedPopupTimer=1500
if /i %maxtimer% LSS %ShowAddedPopupTimer% set maxtimer=%ShowAddedPopupTimer%



::Launch XBMC unless disabled, no new downloads, or it's already running
if /i "%hostname%" NEQ "localhost" goto:skiplaunch
if /i %TotalNotificationS% LSS 1 goto:skiplaunch
if /i "%xbmcLocalLaunch%" EQU "N" goto:skiplaunch
if /i "%notification%" NEQ "1" goto:skiplaunch

::get kodi install path
echo Discovering where\if Kodi is installed...
echo.

reg query HKEY_CURRENT_USER\Software\kodi|findstr /I /C:"Default">"%temp%\temp.txt"
set /p kodipath= <"%temp%\temp.txt"
if "%kodipath%"=="" goto:skipkodi
set kodipath=%kodipath:*REG_SZ    =%

echo Checking if kodi is running...
echo.

::Only launch kodi if not already running
tasklist /nh /fi "imagename eq kodi.exe" | find /i "kodi.exe" >nul && (
echo kodi is already running
echo.
goto:skiplaunch
) || (
echo kodi not running
echo.
)

echo Starting kodi...
echo.
Start /D "%kodipath%" kodi.exe
echo Giving kodi some time to start up...
echo.
@ping 127.0.0.1 -n 25 -w 1000> nul
goto:skiplaunch
:skipkodi


::get xbmc install path
echo Discovering where\if xbmc is installed...
echo.

reg query HKEY_CURRENT_USER\Software\xbmc|findstr /I /C:"Default">"%temp%\temp.txt"
set /p xbmcpath= <"%temp%\temp.txt"
if "%xbmcpath%"=="" goto:skiplaunch
set xbmcpath=%xbmcpath:*REG_SZ    =%

echo Checking if xbmc is running...
echo.

::Only launch xbmc if not already running
tasklist /nh /fi "imagename eq xbmc.exe" | find /i "xbmc.exe" >nul && (
echo xbmc is already running
echo.
goto:skiplaunch
) || (
echo xbmc not running
echo.
)

echo Starting xbmc...
echo.
Start /D "%xbmcpath%" xbmc.exe
echo Giving xbmc some time to start up...
echo.
@ping 127.0.0.1 -n 25 -w 1000> nul

:skiplaunch



::UPDATE LIBRARY - only if enabled and if there are updates, and only for first notification
if /i "%updatelibrary%" NEQ "Y" goto:skipupdate
if /i %TotalNotificationS% LSS 1 goto:skipupdate
if /i "%notification%" NEQ "1" goto:skipupdate

::If update occurred in current or previous minute, skip update for now, at completion wait 1 minute before updating again

::ONLY CHECK FOR FIRST HOST
if /i "%hostnum%" NEQ "1" goto:nocheck
if not exist "%workingdir%\uFilerHistory\%date:/=-%.log" goto:nocheck

set /a priorminute=%time:~3,2%
if /i "%priorminute%" EQU "00" (set /a priorminute=59) else (set /a priorminute=%priorminute%-1)
set /a priorhour=%time:~0,2%

if /i "%priorhour%" NEQ "59" goto:nodeduct
if /i "%priorhour%" EQU "00" (set /a priorhour=23) else (set /apriorhour=%priorhour%-1)
:nodeduct

set priortime=%priorhour%:%priorminute%
::set currenttime=%time:~0,5%
::echo currenttime %currenttime%
::echo priortime %priortime%

findstr /I /B /C:"UPDATE LIBRARY: " "%workingdir%\uFilerHistory\%date:/=-%.log"|findstr /i "%time:~0,5% %priortime%"
IF NOT ERRORLEVEL 1 (set updateskipped=Y) & (goto:skipupdate)
::IF ERRORLEVEL 1 text-not-found
::IF NOT ERRORLEVEL 1 text-found
:nocheck


echo.
echo Updating Kodi\XBMC library...
echo %hostname%:%port%
echo.

::cd /d "%temp%"
::ping -n 1 "%hostname%"|findstr /I /C:"ms"

::"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --user="%username%" --password="%password%" --quiet "%hostname%:%port%/jsonrpc?request={%%22jsonrpc%%22:%%222.0%%22,%%22method%%22:%%22VideoLibrary.Scan%%22}"

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"VideoLibrary.Scan\", \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1


::cd /d "%workingdir%"

::LOG!
if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo UPDATE LIBRARY: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"
:skipupdate


::Send Notification Info
::http://wiki.xbmc.org/index.php?title=JSON-RPC_API/v6#GUI.ShowNotification
::http://wiki.xbmc.org/index.php?title=HOW-TO:Remotely_update_library

if /i "%ShowAddedPopup%" NEQ "Y" goto:EOF

echo Notifying %hostnum%: %hostname%:%port%...
echo.
::cd /d "%temp%"
::ping -n 1 "%hostname%"|findstr /I /C:"ms"

::"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --user="%username%" --password="%password%" --quiet "%hostname%:%port%/jsonrpc?request={%%22jsonrpc%%22:%%222.0%%22,%%22method%%22:%%22GUI.ShowNotification%%22,%%22params%%22:{%%22title%%22:%%22New:%%20%adjseriesname%%%22,%%22message%%22:%%22%adjepisodename%%%22,%%22displaytime%%22:%ShowAddedPopupTimer%,%%22image%%22:%%22%ShowAddedImage%%%22},%%22id%%22:1}"

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"GUI.ShowNotification\", \"params\":{\"title\": \"New: %adjseriesname%\",\"message\": \"%adjepisodename%\",\"displaytime\": %ShowAddedPopupTimer%,\"image\": \"%ShowAddedImage%\"}, \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1


::cd /d "%workingdir%"

::LOG!

if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo SHOW ADDED NOTIFICATION: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %seriesname%: %episodename% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"

goto:EOF



:hostActionFinishedComplete
cd /d "%workingdir%"

if /i "%hostnum%" EQU "0" goto:donenotifications

::Repeat for Next notification\show
set /a delay=%maxtimer:~0,-3%+1

if /i %notification% LSS %TotalNotificationS% @ping 127.0.0.1 -n %delay% -w 1000> nul
if /i %notification% GEQ %TotalNotificationS% goto:donenotifications
goto:RepeatNotification

:donenotifications


::IF Update skipped, wait 90 seconds and then update
if "%updateskipped%"=="" goto:cleantemp

echo Waiting 90 seconds in between library updates
echo.
@ping 127.0.0.1 -n 90 -w 1000> nul

::LOOP through all the xbmc hosts

::dir /s for full path (recursive)
dir /b /s "%workingdir%\XBMChosts">"%temp%\temp.txt"
findstr /I /E /C:".bat" "%temp%\temp.txt" >"%temp%\temp2.txt"
findstr /I /C:"\host" "%temp%\temp2.txt" >"%temp%\xbmchosts.txt"

set hostnum=0
::Loop through the the following once for EACH line in *.txt
cd /d "%temp%"
for /F "tokens=*" %%A in (xbmchosts.txt) do call :update %%A
goto:updateComplete

:update
set /a hostnum=%hostnum%+1
set hostfile=%*
call "%hostfile%"

if /i "%updatelibrary%" NEQ "Y" goto:EOF

echo Updating kodi\XBMC library...
echo %hostname%:%port%
echo.

::cd /d "%temp%"
::ping -n 1 "%hostname%"|findstr /I /C:"ms"


::"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --user="%username%" --password="%password%" --quiet "%hostname%:%port%/jsonrpc?request={%%22jsonrpc%%22:%%222.0%%22,%%22method%%22:%%22VideoLibrary.Scan%%22}"
::cd /d "%workingdir%"

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"VideoLibrary.Scan\", \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1

::LOG!
if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo UPDATE LIBRARY: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"

goto:EOF

:updateComplete



:cleantemp

::Clean temp folder
if exist "%temp%\log.txt" del /f /q "%temp%\log.txt">nul
if exist "%temp%\temp.txt" del /f /q "%temp%\temp.txt">nul
if exist "%temp%\temp2.txt" del /f /q "%temp%\temp2.txt">nul
if exist "%temp%\temp.bat" del /f /q "%temp%\temp.bat">nul
if exist "%temp%\xbmchosts.txt" del /f /q "%temp%\xbmchosts.txt">nul
if exist "%temp%\jsonrpc@request*" del /f /q "%temp%\jsonrpc@request*">nul

if /i "%label%" NEQ "TV" goto:skip
if /i "%force%" EQU "Y" (set label=Movie) & (set LabelOriginal=Movie) & (goto:Movie)

:skip

echo fin
::pause

exit


:simplemovecopy

if /i "%state%" NEQ "11" exit

::Get destination path, first trim label
set destination=%label:~4%
if /i "%label:~2,1%" EQU " " set destination=%label:~3%

set torrentname=%torrentname:&=^&%

if /i "%kind%" EQU "single" set downloadpath=%downloadpath%\%torrentname%


::replace -- with \ and insert : if not a network path

set destination=%destination:--=\%\
if /i "%destination:~-2%" EQU "\\" set destination=%destination:~0,-1%

if /i "%kind%" NEQ "single" set destination=%destination%%torrentname%

if /i "%destination:~0,2%" NEQ "\\" set destination=%destination:~0,1%:%destination:~1%

if not exist "%destination%" mkdir "%destination%"


if not exist "%destination%" exit

if /i "%mode%" EQU "MOVE" echo Moving "%torrentname%"... 
if /i "%mode%" EQU "COPY" echo Copying "%torrentname%"... 

echo From: "%downloadpath%"
echo To: "%destination%"
echo.



xcopy /y /s /q /i "%downloadpath%" "%destination%"|findstr /I /C:"0 File"
IF NOT ERRORLEVEL 1 goto:SkipDeleteAndLog
::IF ERRORLEVEL 1 (echo copy success - text not found) else (echo copy failed - text found)

echo.

::if copy successful and mode=move, delete original
if /i "%mode%" NEQ "move" goto:nodelete
if /i "%kind%" NEQ "single" rd /s /q "%downloadpath%"> nul
if /i "%kind%" EQU "single" del /s /f /q "%downloadpath%">nul
:nodelete

::LOG!
if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo %mode% OPERATION: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo From: %downloadpath% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo To: %destination% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"

:SkipDeleteAndLog
if /i "%label:~0,4%" EQU "-cp " goto:popup
if /i "%label:~0,4%" EQU "-mp " goto:popup

::pause
exit




:popup
set updateskipped=
set torrentname=%torrentname: =.%

::LOOP through all the hosts
::dir /s for full path (recursive)
dir /b /s "%workingdir%\XBMChosts">"%temp%\temp.txt"
findstr /I /E /C:".bat" "%temp%\temp.txt" >"%temp%\temp2.txt"
findstr /I /C:"\host" "%temp%\temp2.txt" >"%temp%\xbmchosts.txt"

set hostnum=0
::set maxtimer=0
::Loop through the following once for EACH line in *.txt
cd /d "%temp%"
for /F "tokens=*" %%A in (xbmchosts.txt) do call :hostActionPopup %%A
goto:hostActionPopupComplete

:hostActionPopup
set /a hostnum=%hostnum%+1
set hostfile=%*

::clear values, just in case
set username=xbmc
set password=pass
set hostname=localhost
set port=8080
set CopyMovePopup=Y
set CopyMovePopupTimer=10000
set CopyMoveImage=
call "%hostfile%"

if /i %CopyMovePopupTimer% LSS 1500 set CopyMovePopupTimer=1500
::if /i %maxtimer% LSS %CopyMovePopupTimer% set maxtimer=%CopyMovePopupTimer%

if /i "%CopyMovePopup%" NEQ "Y" goto:EOF

echo Notifying %hostnum%: %hostname%:%port%...
echo.


::wget timeout bug workaround - ping host to check if online
::::ping -n 1 "%hostname%"|findstr /I /C:"ms"
::IF NOT ERRORLEVEL 1 echo Host Online - ms text found
::pause


::cd /d "%temp%"
::ping -n 1 "%hostname%"|findstr /I /C:"ms"
::"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --user="%username%" --password="%password%" --quiet "%hostname%:%port%/jsonrpc?request={%%22jsonrpc%%22:%%222.0%%22,%%22method%%22:%%22GUI.ShowNotification%%22,%%22params%%22:{%%22title%%22:%%22Download%%20Complete%%22,%%22message%%22:%%22%torrentname%%%22,%%22displaytime%%22:%CopyMovePopupTimer%,%%22image%%22:%%22%CopyMoveImage%%%22},%%22id%%22:1}"

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"GUI.ShowNotification\", \"params\":{\"title\": \"Download Complete\",\"message\": \"%torrentname%\",\"displaytime\": %CopyMovePopupTimer%,\"image\": \"%CopyMoveImage%\"}, \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1

::cd /d "%workingdir%"

::LOG!
if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo DOWNLOAD COMPLETE NOTIFICATION: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %torrentname% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"
goto:EOF


:hostActionPopupComplete
cd /d "%workingdir%"

goto:cleantemp



:teamviewerlaunch

if /i "%previousstate%" NEQ "12" exit

reg query HKEY_LOCAL_MACHINE\Software\WOW6432Node\TeamViewer /v InstallationDirectory|findstr /I /C:"InstallationDirectory">"%temp%\temp.txt"
set /p teamviewerpath= <"%temp%\temp.txt"
if "%teamviewerpath%"=="" (exit)
set teamviewerpath=%teamviewerpath:*REG_SZ    =%

::Only launch teamviewer if not already running
tasklist /nh /fi "imagename eq teamviewer.exe" | find /i "teamviewer.exe" >nul && (
echo teamviewer is already running
echo.
exit
) || (
echo starting teamviewer
echo.
)

Start /D "%teamviewerpath%" teamviewer.exe

exit

:taskkill
if /i "%previousstate%" NEQ "12" exit
if /i "%label:~-4%" NEQ ".exe" (taskkill /im "%label:~5%.exe" /f ) else (taskkill /im "%label:~5%" /f )
exit







:Movie

::Queued utorrent state (12)
if /i "%state%" NEQ "F" if /i "%previousstate%" EQU "12" goto:DOWNLOADSTART

if not exist settings.bat goto:cleantemp

if "%uCompletedDownloads%"=="" goto:cleantemp
if "%MovieFolder%"=="" goto:cleantemp

if not exist "%uCompletedDownloads%" goto:cleantemp

if not exist "%MovieFolder%" mkdir "%MovieFolder%"
if not exist "%MovieFolder%" goto:cleantemp

::if copyORmove=move, trigger completion at torrent finished state (11), otherwise trigger completion at seeding (or finished) state (4,5,7,8,10)
::even if triggered multiple times, duplicate notifications will not appear because filebot will only log it once

::FORCE run
if /i "%state%" EQU "F" goto:FINISHEDMovie

::For Move operations
if /i "%copyORmove%" NEQ "move" goto:skip
if /i "%state%" EQU "11" goto:FINISHEDMovie
goto:cleantemp

::For Copy disabled
:skip
if /i "%state%" EQU "4" goto:FINISHEDMovie
if /i "%state%" EQU "5" goto:FINISHEDMovie
if /i "%state%" EQU "7" goto:FINISHEDMovie
if /i "%state%" EQU "8" goto:FINISHEDMovie
if /i "%state%" EQU "10" goto:FINISHEDMovie
if /i "%state%" EQU "11" goto:FINISHEDMovie
goto:cleantemp



:FINISHEDMovie
echo Movie Finished Process
echo.
set filebot="uninstalled"
if exist "%homedrive%\Program Files (x86)\FileBot\filebot.exe" set filebot="%homedrive%\Program Files (x86)\FileBot\filebot.exe"
if exist "%homedrive%\Program Files\FileBot\filebot.exe" set filebot="%homedrive%\Program Files\FileBot\filebot.exe"
if /i %filebot% EQU "uninstalled" goto:cleantemp

set updateskipped=

::TO DO - override uCompletedDownloads with uTorrent label
::if not exist "%uCompletedDownloads%" goto:cleantemp

::clean "%uCompletedDownloads%\%LabelOriginal%" (only if copyORmove=move to not disrupt seeding)
if /i "%copyORmove%" NEQ "move" goto:skip

echo Cleaning fetchfolder of:
echo txt, nfo, jpg, png, ac3, ~uTorrentPart dat files, empty folders and
echo sample files based on name or size --less than 30MB and not a subtitle extension--
echo.
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.jpg">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.png">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.txt">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.nfo">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*.ac3">nul
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*~uTorrentPartFile*.dat">nul
::delete samples
del /s /f /q "%uCompletedDownloads%\%LabelOriginal%\*sample*">nul
::delete video files that are less than 30MB (or 31457280 in bytes)
for /f "delims=" %%d in ('dir /s /b /a-d "%uCompletedDownloads%\%LabelOriginal%\*" ^| findstr /I /V ".srt .sub .ssa .sbv"') do if %%~zd lss 31457280 del /s /f /q "%%~d"

for /f "delims=" %%d in ('dir /s /b /ad "%uCompletedDownloads%\%LabelOriginal%\" ^| sort /r') do rd "%%d"
echo.


:skip


if /i "%GetSubtitles%" NEQ "Y" goto:skip
echo Checking for subtitles...
echo.
%filebot% -script fn:suball "%uCompletedDownloads%\%LabelOriginal%" --lang %SubtitleLang% --output srt --encoding utf8 -non-strict --format MATCH_VIDEO
echo.
:skip


echo Launching filebot to %copyORmove% and rename files...
echo.

::if not exist list.csv echo Star Trek The Next Generation;STNG>>list.csv

%filebot% -rename --action %copyORmove% --conflict auto --db TheMovieDB -r -non-strict --format "%MovieFolder%\%MovieFormat%" "%uCompletedDownloads%\%LabelOriginal%">"%temp%\log.txt" 2>&1


if /i "%copyORmove%" EQU "move" echo Launching filebot to clean files...
if /i "%copyORmove%" EQU "move" echo.
if /i "%copyORmove%" EQU "move" %filebot% -script fn:cleaner "%uCompletedDownloads%\%LabelOriginal%"

echo Reading logs...
echo.



cd /d "%temp%"

::remove sub lines

::findstr /I /V ".srt .sub .idx .jpg .nfo" "%temp%\log.txt" >"%temp%\temp.txt"
::above doesn't consider periods, i.e. excludes "HorribleSubs" because of ".sub"

findstr /I /V /C:".srt" "%temp%\log.txt" >"%temp%\temp.txt"
findstr /I /V /C:".sub" "%temp%\temp.txt" >"%temp%\log.txt"
findstr /I /V /C:".idx" "%temp%\log.txt" >"%temp%\temp.txt"
findstr /I /V /C:".jpg" "%temp%\temp.txt" >"%temp%\log.txt"
findstr /I /V /C:".nfo" "%temp%\log.txt" >"%temp%\temp.txt"


::Count NEW
findstr /I /C:"] to [" "%temp%\temp.txt" >"%temp%\log.txt"

set TotalNotificationS=0
::Loop through the the following once for EACH line in *.txt
for /F "tokens=*" %%A in (log.txt) do call :countnum "%%A"
goto:quickskip
:countnum
set /a TotalNotificationS=%TotalNotificationS%+1
goto:EOF
:quickskip
echo TotalNotifications %TotalNotificationS%
echo.

cd /d "%workingdir%"

:skipcount


set /a notification=0

:RepeatNotificationMovie
if /i %notification% EQU %TotalNotificationS% goto:donenotifications
set /a notification=%notification%+1
echo.
echo Notification %notification%

::Number the list
findstr /I /N "." "%temp%\log.txt" >"%temp%\temp.txt"

::pull episode name and series name from notification #
findstr /I /B /C:"%notification%:" "%temp%\temp.txt" >"%temp%\temp2.txt"
set /p filename= <"%temp%\temp2.txt"

echo set filename=%%filename:*%MovieFolder%\=%%>"%temp%\temp.bat"
call "%temp%\temp.bat"

set filename=%filename:~0,-1%
set fullname=%filename%

set filename=%filename:*\=%
set filename=%filename:*\=%
set filename=%filename:*\=%

::echo filename %filename%

echo set videofolder=%%fullname:%filename%=%%>"%temp%\temp.bat"
call "%temp%\temp.bat"

if not "%videofolder%"=="" set videofolder=%MovieFolder%\%videofolder%
if "%videofolder%"=="" set videofolder=%MovieFolder%
if "%videofolder:~-1,1%" EQU "\" set videofolder=%videofolder:~0,-1%

::echo videofolder %videofolder%

if "%filename:~-4,1%" EQU "." set filename=%filename:~0,-4%
if "%filename:~-5,1%" EQU "." set filename=%filename:~0,-5%
::echo filename %filename%


echo.
echo %notification%: %filename%
echo.

::UpdatePlexLibrary

if "%updatePlexLibrary%" EQU "N" goto:skipPlexUpdate
if "%updatePlexLibrary%" EQU "localhost" goto:localhostplexupdate
if "%updatePlexLibrary%" EQU "Y" goto:localhostplexupdate

::remote plex library update

::get Section #
"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --quiet "http://%updatePlexLibrary%:%PlexPort%/library/sections?X-Plex-Token=%PlexToken%" -O "%temp%\temp.txt"

::redirects fail for findstr commands containing escaped characters, work around by calling other bat file
echo @findstr /I /C:^"title=\^"%%1^" ^"%%temp%%\temp.txt^">"%temp%\myfindstr.bat"
call "%temp%\myfindstr.bat" %label% >"%temp%\temp2.txt"

set /p section= <"%temp%\temp2.txt"

set section=%section:*sections/=%
if "%section:~1,1%" EQU "/" (set section=%section:~0,1%) & (goto:gotsection)
if "%section:~2,1%" EQU "/" (set section=%section:~0,2%) & (goto:gotsection)
if "%section:~3,1%" EQU "/" (set section=%section:~0,3%) & (goto:gotsection)
if "%section:~4,1%" EQU "/" (set section=%section:~0,4%) & (goto:gotsection)
if "%section:~5,1%" EQU "/" (set section=%section:~0,5%) & (goto:gotsection)
:gotsection
::echo %section%


::send update command
echo Updating %label% Plex Library: %updatePlexLibrary%:%PlexPort%
echo.

"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --quiet "http://%updatePlexLibrary%:%PlexPort%/library/sections/%section%/refresh?X-Plex-Token=%PlexToken%" -O "%temp%\temp.txt"

goto:skipPlexUpdate


::Local UpdatePlexLibrary, only for the specific "%videofolder%"

:localhostplexupdate
if "%updatePlexLibrary%" NEQ "localhost" goto:skipPlexUpdate

set PMS="uninstalled"
if exist "%homedrive%\Program Files (x86)\Plex\Plex Media Server\Plex Media Scanner.exe" set PMS="%homedrive%\Program Files (x86)\Plex\Plex Media Server\Plex Media Scanner.exe"
if exist "%homedrive%\Program Files\Plex\Plex Media Server\Plex Media Scanner.exe" set PMS="%homedrive%\Program Files\Plex\Plex Media Server\Plex Media Scanner.exe"
if /i %PMS% EQU "uninstalled" goto:skipPlexUpdate

::get %label% section number
%PMS% --list|findstr /I /C:" %label%">"%temp%\temp.txt"

set /p section= <"%temp%\temp.txt"
if "%section%"=="" goto:skipPlexUpdate

set section=%section: =%
if /i "%section:~1,1%" EQU ":" set section=%section:~0,1%
if /i "%section:~2,1%" EQU ":" set section=%section:~0,2%
if /i "%section:~3,1%" EQU ":" set section=%section:~0,3%
if "%section%"=="" goto:skipPlexUpdate

echo Updating Plex Library
echo --scan --refresh --section %section% -d "%videofolder%"
echo.
%PMS% --scan --refresh --section %section% -d "%videofolder%"
echo.
:skipPlexUpdate


::replace ampersands ("&") with "and"
set filename=%filename:&=^&%
set filename=%filename:^&=and%

::replace spaces with %%20 (no longer needed since switching to curl)
set adjfilename=%filename%
::setlocal ENABLEDELAYEDEXPANSION
::set adjfilename=!filename: =%%20!
::setlocal DISABLEDELAYEDEXPANSION


::echo %adjfilename%


::LOOP through all the xbmc hosts
::dir /s for full path (recursive)
dir /b /s "%workingdir%\XBMChosts">"%temp%\temp.txt"
findstr /I /E /C:".bat" "%temp%\temp.txt" >"%temp%\temp2.txt"
findstr /I /C:"\host" "%temp%\temp2.txt" >"%temp%\xbmchosts.txt"


set hostnum=0
set maxtimer=0
::Loop through the the following once for EACH line in *.txt
cd /d "%temp%"
for /F "tokens=*" %%A in (xbmchosts.txt) do call :hostActionFinishedMovie %%A
goto:hostActionFinishedCompleteMovie

:hostActionFinishedMovie
set /a hostnum=%hostnum%+1
set hostfile=%*

::clear values, just in case
set username=xbmc
set password=pass
set hostname=localhost
set port=8080
set updatelibrary=Y
set ShowAddedPopup=Y
set ShowAddedPopupTimer=5000
set ShowAddedImage=
set xbmcLocalLaunch=Y

call "%hostfile%"

if /i %ShowAddedPopupTimer% LSS 1500 set ShowAddedPopupTimer=1500
if /i %maxtimer% LSS %ShowAddedPopupTimer% set maxtimer=%ShowAddedPopupTimer%


::Launch XBMC unless disabled, no new downloads, or it's already running
if /i "%hostname%" NEQ "localhost" goto:skiplaunch
if /i %TotalNotificationS% LSS 1 goto:skiplaunch
if /i "%xbmcLocalLaunch%" EQU "N" goto:skiplaunch

::get kodi install path
echo Discovering where\if Kodi is installed...
echo.

reg query HKEY_CURRENT_USER\Software\kodi|findstr /I /C:"Default">"%temp%\temp.txt"
set /p kodipath= <"%temp%\temp.txt"
if "%kodipath%"=="" goto:skipkodi
set kodipath=%kodipath:*REG_SZ    =%

echo Checking if kodi is running...
echo.

::Only launch kodi if not already running
tasklist /nh /fi "imagename eq kodi.exe" | find /i "kodi.exe" >nul && (
echo kodi is already running
echo.
goto:skiplaunch
) || (
echo kodi not running
echo.
)

echo Starting kodi...
echo.
Start /D "%kodipath%" kodi.exe
echo Giving kodi some time to start up...
echo.
@ping 127.0.0.1 -n 60 -w 1000> nul
goto:skiplaunch
:skipkodi


::get xbmc install path
echo Discovering where\if xbmc is installed...
echo.

reg query HKEY_CURRENT_USER\Software\xbmc|findstr /I /C:"Default">"%temp%\temp.txt"
set /p xbmcpath= <"%temp%\temp.txt"
if "%xbmcpath%"=="" goto:skiplaunch
set xbmcpath=%xbmcpath:*REG_SZ    =%

echo Checking if xbmc is running...
echo.

::Only launch xbmc if not already running
tasklist /nh /fi "imagename eq xbmc.exe" | find /i "xbmc.exe" >nul && (
echo xbmc is already running
echo.
goto:skiplaunch
) || (
echo xbmc not running
echo.
)

echo Starting xbmc...
echo.
Start /D "%xbmcpath%" xbmc.exe
echo Giving xbmc some time to start up...
echo.
@ping 127.0.0.1 -n 60 -w 1000> nul

:skiplaunch



::UPDATE LIBRARY - only if enabled and if there are updates, and only for first notification
if /i "%updatelibrary%" NEQ "Y" goto:skipupdate
if /i %TotalNotificationS% LSS 1 goto:skipupdate
if /i "%notification%" NEQ "1" goto:skipupdate

::If update occurred in current or previous minute, skip update for now, at completion wait 1 minute before updating again

::ONLY CHECK FOR FIRST HOST
if /i "%hostnum%" NEQ "1" goto:nocheck
if not exist "%workingdir%\uFilerHistory\%date:/=-%.log" goto:nocheck

set /a priorminute=%time:~3,2%
if /i "%priorminute%" EQU "00" (set /a priorminute=59) else (set /a priorminute=%priorminute%-1)
set /a priorhour=%time:~0,2%

if /i "%priorhour%" NEQ "59" goto:nodeduct
if /i "%priorhour%" EQU "00" (set /a priorhour=23) else (set /apriorhour=%priorhour%-1)
:nodeduct

set priortime=%priorhour%:%priorminute%
::set currenttime=%time:~0,5%
::echo currenttime %currenttime%
::echo priortime %priortime%

findstr /I /B /C:"UPDATE LIBRARY: " "%workingdir%\uFilerHistory\%date:/=-%.log"|findstr /i "%time:~0,5% %priortime%"
IF NOT ERRORLEVEL 1 (set updateskipped=Y) & (goto:skipupdate)
::IF ERRORLEVEL 1 text-not-found
::IF NOT ERRORLEVEL 1 text-found
:nocheck


echo.
echo Updating Kodi\XBMC library...
echo %hostname%:%port%
echo.

::cd /d "%temp%"
::ping -n 1 "%hostname%"|findstr /I /C:"ms"
::"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --user="%username%" --password="%password%" --quiet "%hostname%:%port%/jsonrpc?request={%%22jsonrpc%%22:%%222.0%%22,%%22method%%22:%%22VideoLibrary.Scan%%22}"
::cd /d "%workingdir%"

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"VideoLibrary.Scan\", \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1

::LOG!
if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo UPDATE LIBRARY: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"
:skipupdate


::Send Notification Info
::http://wiki.xbmc.org/index.php?title=JSON-RPC_API/v6#GUI.ShowNotification
::http://wiki.xbmc.org/index.php?title=HOW-TO:Remotely_update_library

if /i "%ShowAddedPopup%" NEQ "Y" goto:EOF

echo Notifying %hostnum%: %hostname%:%port%...
echo.
::cd /d "%temp%"
::ping -n 1 "%hostname%"|findstr /I /C:"ms"

::"%workingdir%\wget.exe" --no-check-certificate --timeout=5 -t 1 --user="%username%" --password="%password%" --quiet "%hostname%:%port%/jsonrpc?request={%%22jsonrpc%%22:%%222.0%%22,%%22method%%22:%%22GUI.ShowNotification%%22,%%22params%%22:{%%22title%%22:%%22New Movie:%%22,%%22message%%22:%%22%adjfilename%%%22,%%22displaytime%%22:%ShowAddedPopupTimer%,%%22image%%22:%%22%ShowAddedImage%%%22},%%22id%%22:1}"

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"GUI.ShowNotification\", \"params\":{\"title\": \"New Movie:\",\"message\": \"%adjfilename%\",\"displaytime\": %ShowAddedPopupTimer%,\"image\": \"%ShowAddedImage%\"}, \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1





::cd /d "%workingdir%"

::LOG!

if not exist "%workingdir%\uFilerHistory" mkdir "%workingdir%\uFilerHistory"
echo MOVIE ADDED NOTIFICATION: %time:~0,5% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %filename% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo %hostname%:%port% >> "%workingdir%\uFilerHistory\%date:/=-%.log"
echo --- >> "%workingdir%\uFilerHistory\%date:/=-%.log"

goto:EOF


:hostActionFinishedCompleteMovie
cd /d "%workingdir%"

if /i "%hostnum%" EQU "0" goto:donenotifications

::Repeat for Next notification\show
set /a delay=%maxtimer:~0,-3%+1

if /i %notification% LSS %TotalNotificationS% @ping 127.0.0.1 -n %delay% -w 1000> nul
if /i %notification% GEQ %TotalNotificationS% goto:donenotifications
goto:RepeatNotificationMovie


:noargs
::if compiling, uncomment next 2 lines
::if "%workingdir%"=="" start http://uFiler.wordpress.com/installation
::Exit

::check if utorrent installed
if exist "%appdata%\uTorrent\uTorrent.exe" goto:skiputorrent
if exist "%homedrive%\Program Files (x86)\uTorrent\uTorrent.exe" goto:skiputorrent
if exist "%homedrive%\Program Files\uTorrent\uTorrent.exe" goto:skiputorrent

set answer=
cls
echo uFiler v%version%
echo -----------
echo.
echo Missing uTorrent, install it now?
echo.
echo      Y = Yes
echo      N = No
echo.
set /p answer=     Enter Selection Here: 

if /i "%answer%" EQU "n" goto:skiputorrent
if /i "%answer%" NEQ "y" goto:noargs

start /min /wait wget --no-check-certificate -t 3 "http://download-new.utorrent.com/uuid/4ab0540f-21dc-46e3-ac68-fb8d5a1c9032"
rename "4ab0540f-21dc-46e3-ac68-fb8d5a1c9032" uTorrent.exe
start uTorrent.exe
:skiputorrent


:filebotcheck
::check if filebot is installed
if exist "%homedrive%\Program Files (x86)\FileBot\filebot.exe" goto:skipfilebotcheck
if exist "%homedrive%\Program Files\FileBot\filebot.exe" goto:skipfilebotcheck

set answer=
cls
echo uFiler v%version%
echo -----------
echo.
echo Missing filebot (optional but required for primary functions), install it now?
echo.
echo Note, if you encounter errors during installation, temporarily disable your anti-virus.
echo.
echo      Y = Yes
echo      N = No
echo.
set /p answer=     Enter Selection Here: 

if /i "%answer%" EQU "n" goto:skipfilebotcheck
if /i "%answer%" NEQ "y" goto:filebotcheck

start /min /wait wget --no-check-certificate -t 3 "https://www.filebot.net/download.php?mode=s^&type=nsis"
start FileBot-setup.exe
:skipfilebotcheck


:usage
set answer=
cls
echo uFiler v%version%
echo -----------
echo.
echo Go to uFiler.wordpress.com for usage information
echo.
echo Exiting...
@ping 127.0.0.1 -n 3 -w 1000> nul
exit
