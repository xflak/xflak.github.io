@echo off
setlocal
set PATH=%SystemRoot%\system32;%SystemRoot%\system32\wbem;%SystemRoot%
chcp 437>nul

set workingdir=%cd%

dir /b /s "%workingdir%\XBMChosts">"%temp%\temp.txt"
findstr /I /E /C:".bat" "%temp%\temp.txt" >"%temp%\temp2.txt"
findstr /I /C:"\host" "%temp%\temp2.txt" >"%temp%\xbmchosts.txt"

set hostnum=0
cd /d "%temp%"
for /F "tokens=*" %%A in (xbmchosts.txt) do call :hostAction %%A
goto:hostActionComplete

:hostAction
set /a hostnum=%hostnum%+1
set hostfile=%*

set username=xbmc
set password=pass
set hostname=localhost
set port=8080
set updatelibrary=Y
set ShowAddedPopup=Y
set ShowAddedPopupTimer=5000
set ShowAddedImage=
set xbmcLocalLaunch=Y

call "%hostfile%"

if /i "%updatelibrary%" NEQ "Y" goto:skipupdate



::Launch XBMC unless disabled, no new downloads, or it's already running
if /i "%hostname%" NEQ "localhost" goto:skiplaunch
if /i "%xbmcLocalLaunch%" EQU "N" goto:skiplaunch

::get kodi install path
echo Discovering where\if Kodi is installed...
echo.

reg query HKEY_CURRENT_USER\Software\kodi|findstr /I /C:"Default">"%temp%\temp.txt"
set /p kodipath= <"%temp%\temp.txt"
if "%kodipath%"=="" goto:skipkodi
set kodipath=%kodipath:*REG_SZ    =%

echo Checking if kodi is running...
echo.

::Only launch kodi if not already running
tasklist /nh /fi "imagename eq kodi.exe" | find /i "kodi.exe" >nul && (
echo kodi is already running
echo.
goto:skiplaunch
) || (
echo kodi not running
echo.
)

echo Starting kodi...
echo.
Start /D "%kodipath%" kodi.exe
echo Giving kodi some time to start up...
echo.
@ping 127.0.0.1 -n 20 -w 1000> nul
goto:skiplaunch

:skipkodi



::get xbmc install path
echo Discovering where\if xbmc is installed...
echo.

reg query HKEY_CURRENT_USER\Software\xbmc|findstr /I /C:"Default">"%temp%\temp.txt"
set /p xbmcpath= <"%temp%\temp.txt"
if "%xbmcpath%"=="" goto:skiplaunch
set xbmcpath=%xbmcpath:*REG_SZ    =%

echo Checking if xbmc is running...
echo.

::Only launch xbmc if not already running
tasklist /nh /fi "imagename eq xbmc.exe" | find /i "xbmc.exe" >nul && (
echo xbmc is already running
echo.
goto:skiplaunch
) || (
echo xbmc not running
echo.
)

echo Starting xbmc...
echo.
Start /D "%xbmcpath%" xbmc.exe
echo Giving xbmc some time to start up...
echo.
@ping 127.0.0.1 -n 20 -w 1000> nul

:skiplaunch





echo Updating Kodi\XBMC library...
echo %hostname%:%port%
echo.

"%workingdir%\curl.exe" -i -X POST -d "{\"jsonrpc\": \"2.0\", \"method\": \"VideoLibrary.Scan\", \"id\": \"mybash\"}" -H "content-type:application/json" http://%username%:%password%@%hostname%:%port%/jsonrpc> NUL 2>&1



:skipupdate

goto:EOF


:hostActionComplete

::Clean temp folder, jsonrpc files can add up over time
if exist "%temp%\temp.txt" del /f /q "%temp%\temp.txt">nul
if exist "%temp%\temp2.txt" del /f /q "%temp%\temp2.txt">nul
::if exist "%temp%\temp.bat" del /f /q "%temp%\temp.bat">nul
if exist "%temp%\xbmchosts.txt" del /f /q "%temp%\xbmchosts.txt">nul
if exist "%temp%\jsonrpc@request*" del /s /f /q "%temp%\jsonrpc@request*">nul


::echo fin
::pause

exit